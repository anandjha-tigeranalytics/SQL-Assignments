
-- 1. Provide department wise employee count under each title
SELECT *
FROM
    (SELECT
        w.DEPARTMENT,
        t.WORKER_TITLE,
        w.WORKER_ID
    FROM Worker AS w
    JOIN Title AS t
        ON w.WORKER_ID = t.WORKER_REF_ID
    ) AS Pivot_Data
PIVOT (
    COUNT(WORKER_ID) FOR WORKER_TITLE IN ('Manager', 'Executive', 'Asst. Manager', 'Lead')
) AS Pivot_Results
ORDER BY 1;


-- 2. List all the workers with salary higher than department's average salary

WITH DeptAvgSalary AS (
    SELECT
        DEPARTMENT,
        AVG(SALARY) AS Avg_Dept_Salary
    FROM Worker
    GROUP BY DEPARTMENT
)
SELECT
    w.WORKER_ID,
    w.FIRST_NAME,
    w.LAST_NAME,
    t.WORKER_TITLE,
    w.SALARY,
    w.DEPARTMENT
FROM Worker AS w
JOIN DeptAvgSalary AS das
    ON w.DEPARTMENT = das.DEPARTMENT
JOIN Title AS t
    ON w.WORKER_ID = t.WORKER_REF_ID
WHERE w.SALARY > das.Avg_Dept_Salary;


-- 3. Identify Managers with Earnings Less Than Department Average Earnings (Salary+Bonus)

WITH WorkerTotalEarnings AS (
    SELECT
        w.WORKER_ID,
        w.FIRST_NAME,
        w.LAST_NAME,
        w.DEPARTMENT,
        t.WORKER_TITLE,
        w.SALARY + IFNULL(SUM(b.BONUS_AMOUNT), 0) AS Total_Earnings
    FROM Worker AS w
    JOIN Title AS t
        ON w.WORKER_ID = t.WORKER_REF_ID
    LEFT JOIN Bonus AS b
        ON w.WORKER_ID = b.WORKER_REF_ID
    GROUP BY w.WORKER_ID, w.FIRST_NAME, w.LAST_NAME, w.DEPARTMENT, t.WORKER_TITLE, w.SALARY
),
DeptAvgEarnings AS (
    SELECT
        DEPARTMENT,
        AVG(Total_Earnings) AS Avg_Dept_Earnings
    FROM WorkerTotalEarnings
    GROUP BY DEPARTMENT
)
SELECT
    wte.WORKER_ID,
    wte.FIRST_NAME,
    wte.LAST_NAME,
    wte.DEPARTMENT,
    wte.WORKER_TITLE,
    wte.Total_Earnings
FROM WorkerTotalEarnings AS wte
JOIN DeptAvgEarnings AS dae
    ON wte.DEPARTMENT = dae.DEPARTMENT
WHERE
    wte.WORKER_TITLE = 'Manager'
    AND wte.Total_Earnings < dae.Avg_Dept_Earnings;


-- 4. Find out which worker got the highest bonus. Display their work title as well.

SELECT
    w.WORKER_ID,
    w.FIRST_NAME,
    w.LAST_NAME,
    t.WORKER_TITLE,
    b.BONUS_AMOUNT
FROM Bonus AS b
JOIN Worker AS w
    ON b.WORKER_REF_ID = w.WORKER_ID
JOIN Title AS t
    ON w.WORKER_ID = t.WORKER_REF_ID
ORDER BY b.BONUS_AMOUNT DESC
LIMIT 1;


-- 5. Identify employees who received a promotion, and a salary increase within the same year.
-- This is not possible with the provided schema. The 'Title' table only has one entry per worker,
-- and the 'Worker' table only has the current salary. To answer this, we would need
-- a history of all title changes with corresponding dates, and a history of all salary changes.
-- The current data does not support this.


-- 6. Calculate the percentage salary increase for each promotion.
-- This is also not possible with the current schema. To calculate a percentage salary increase,
-- we would need both the previous salary and the new salary. The 'Worker' table
-- only stores the current salary, and there is no historical salary data.


-- 7. Rank employees by their total bonus amount within each department.

WITH WorkerTotalBonus AS (
    SELECT
        WORKER_REF_ID,
        SUM(BONUS_AMOUNT) AS Total_Bonus
    FROM Bonus
    GROUP BY WORKER_REF_ID
)
SELECT
    w.WORKER_ID,
    w.FIRST_NAME,
    w.LAST_NAME,
    w.DEPARTMENT,
    wtb.Total_Bonus,
    DENSE_RANK() OVER (PARTITION BY w.DEPARTMENT ORDER BY wtb.Total_Bonus DESC) AS Bonus_Rank
FROM Worker AS w
JOIN WorkerTotalBonus AS wtb
    ON w.WORKER_ID = wtb.WORKER_REF_ID
ORDER BY w.DEPARTMENT, Bonus_Rank;




-- 8. Identify the difference between each employee’s bonus and the highest bonus in their department.

WITH DepartmentMaxBonus AS (
    SELECT
        w.DEPARTMENT,
        MAX(b.BONUS_AMOUNT) AS Max_Bonus
    FROM Bonus AS b
    JOIN Worker AS w
        ON b.WORKER_REF_ID = w.WORKER_ID
    GROUP BY w.DEPARTMENT
)
SELECT
    w.WORKER_ID,
    w.FIRST_NAME,
    w.LAST_NAME,
    w.DEPARTMENT,
    b.BONUS_AMOUNT,
    dmb.Max_Bonus,
    dmb.Max_Bonus - b.BONUS_AMOUNT AS Bonus_Difference
FROM Bonus AS b
JOIN Worker AS w
    ON b.WORKER_REF_ID = w.WORKER_ID
JOIN DepartmentMaxBonus AS dmb
    ON w.DEPARTMENT = dmb.DEPARTMENT
ORDER BY w.DEPARTMENT, w.FIRST_NAME, b.BONUS_AMOUNT;


-- 9. Calculate the cumulative bonus for each department, ordered by bonus date.

SELECT
    b.WORKER_REF_ID,
    w.DEPARTMENT,
    b.BONUS_DATE,
    b.BONUS_AMOUNT,
    SUM(b.BONUS_AMOUNT) OVER (PARTITION BY w.DEPARTMENT ORDER BY b.BONUS_DATE) AS Cumulative_Bonus
FROM Bonus AS b
JOIN Worker AS w
    ON b.WORKER_REF_ID = w.WORKER_ID
ORDER BY w.DEPARTMENT, b.BONUS_DATE;


-- 10. Identify the number of promotions employees have received over their career.


SELECT 
    W.WORKER_ID,
    W.FIRST_NAME,
    W.LAST_NAME,
    COUNT(T.WORKER_TITLE) - 1 AS NUM_PROMOTIONS
FROM Worker W
LEFT JOIN Title T ON W.WORKER_ID = T.WORKER_REF_ID
GROUP BY W.WORKER_ID, W.FIRST_NAME, W.LAST_NAME;

-- 11. Calculate the average time spent in each role (time between promotions).
-- This is not possible with the provided data, for the same reason as question 10.
-- we would need a history of title changes with `AFFECTED_FROM` dates to calculate
-- the duration of each role.



-- 12. Identify employees who have spent more time in their current role compared to their previous role.
-- This is not possible with the provided data, as it requires a history of promotions
-- and their start dates. This is a classic "LAG" function use case, but the necessary
-- historical data is missing from the tables.

create  database traning;
-- 2. Create a table 'demography'.

CREATE TABLE demography (
  CustID INT IDENTITY(1,1) PRIMARY KEY,
  Name VARCHAR(50),
  Age INT,
  Gender VARCHAR(1)
);

-- 3. Insert one value.
INSERT INTO demography (Name, Age, Gender) VALUES ('John', 25, 'M');

-- 4. Insert multiple values using a single query.
INSERT INTO demography (Name, Age, Gender)
VALUES
  ('Pawan', 26, 'M'),
  ('Hema', 31, 'F');

-- 5. Insert a value without an age.
INSERT INTO demography (Name, Gender) VALUES ('Rekha', 'F');

-- 6. Retrieve all rows and columns.
SELECT * FROM demography;

-- 7. Update the age for 'John' to NULL.
UPDATE demography SET Age = NULL WHERE Name = 'John';

-- 8. Retrieve rows where Age is NULL.
SELECT * FROM demography WHERE Age IS NULL;

-- 9. Delete all rows from the table.
DELETE FROM demography;

-- 10. Drop the table 'demography'.
DROP TABLE demography;


-- Snowflake Assignment 2 - Where Clause

-- 1. Retrieve the account ID, customer ID, and available balance for all accounts whose status is 'ACTIVE' and available balance is greater than $2,500.
SELECT account_id, cust_id, avail_balance
FROM account
WHERE status = 'ACTIVE' AND avail_balance > 2500;

-- 2. Construct a query that retrieves all accounts opened in 2002.
SELECT *
FROM account
WHERE YEAR(open_date) = 2002;

-- 3. Retrieve the account ID, available balance and pending balance for all accounts where available balance is not equal to pending balance.
SELECT account_id, avail_balance, pending_balance
FROM account
WHERE avail_balance != pending_balance;

-- 4. Retrieve account ID, Product code for the account ID’s 1, 10, 23, 27.
SELECT account_id, product_cd
FROM account
WHERE account_id IN (1, 10, 23, 27);

-- 5. Retrieve account ID, available balance from all those accounts whose available balance is in between 100 and 200.
SELECT account_id, avail_balance
FROM account
WHERE avail_balance BETWEEN 100 AND 200;

select * from customer;
-- Snowflake Assignment 3 - Operators and Functions

-- 1. Construct a query that counts the number of rows in the account table.
SELECT COUNT(*) FROM account;

-- 2. Retrieve the first two rows from account table.
SELECT * FROM account LIMIT 2;

-- 3. Retrieve the third and fourth row from account table.
SELECT * FROM account LIMIT 2 OFFSET 2;

-- 4. Retrieve year of birth, month of birth, day of birth, weekday of birth for all individuals.
SELECT
  birth_date,
  YEAR(birth_date) AS year_of_birth,
  MONTH(birth_date) AS month_of_birth,
  DAY(birth_date) AS day_of_birth,
  DAYNAME(birth_date) AS weekday_of_birth
FROM individual;

-- 5. Write a query that returns the 17th through 25th characters of the string 'Please find the substring in this string'.
SELECT SUBSTRING('Please find the substring in this string', 17, 9);

-- 6. Write a query that returns the absolute value, sign, and rounded value of the number -25.76823.
SELECT
  ABS(-25.76823) AS absolute_value,
  SIGN(-25.76823) AS sign_value,
  ROUND(-25.76823, 2) AS rounded_value;
  
-- 7. Write a query that adds 30 days to the current date.
SELECT DATE_ADD(day, 30, CURRENT_DATE());

-- 8. Retrieve the first three letters of first name and last three letters of last name from the table individual.
SELECT
  LEFT(fname, 3) AS first_three_fname,
  RIGHT(lname, 3) AS last_three_lname
FROM individual;

-- 9. Retrieve the first names in Upper case from individual whose first name consists of five characters.
SELECT UPPER(fname)
FROM individual
WHERE LENGTH(fname) = 5;

-- 10. Retrieve the maximum balance and average balance from the account table for customer ID = 1.
SELECT
  MAX(avail_balance) AS max_balance,
  AVG(avail_balance) AS avg_balance
FROM account
WHERE cust_id = 1;


-- Snowflake Assignment 4 - Group by

-- 1. Construct a query to count the number of accounts held by each customer.
SELECT cust_id, COUNT(account_id) AS number_of_accounts
FROM account
GROUP BY cust_id;

-- 2. Modify the previous query to fetch only those customers who have more than two accounts.
SELECT cust_id, COUNT(account_id) AS number_of_accounts
FROM account
GROUP BY cust_id
HAVING COUNT(account_id) > 2;

-- 3. Retrieve first name and date of birth from individual and sort them from youngest to oldest.
SELECT fname, birth_date
FROM individual
ORDER BY birth_date DESC;

-- 4. From the account table, retrieve the year of account opening and average available balance for each calendar year.
SELECT
  YEAR(open_date) AS open_year,
  AVG(avail_balance) AS avg_balance
FROM account
GROUP BY open_year
HAVING AVG(avail_balance) > 200
ORDER BY open_year;

-- 5. Retrieve the product code and maximum pending balance for the product codes (CHK, SAV, CD).
SELECT
  product_cd,
  MAX(pending_balance) AS max_pending_balance
FROM account
WHERE product_cd IN ('CHK', 'SAV', 'CD')
GROUP BY product_cd;


-- Snowflake Assignment 5 - Joins and Sub-query

-- 1. Retrieve first name, title and department name by joining tables employee and department.
SELECT e.fname, e.title, d.name AS department_name
FROM employee e
JOIN department d
  ON e.dept_id = d.dept_id;

-- 2. Left join table product with table product_type.
SELECT pt.name AS product_type_name, p.name AS product_name
FROM product_type pt
LEFT JOIN product p
  ON pt.product_type_cd = p.product_type_cd;

-- 3. Using inner join, retrieve the full employee name and Superior name from the employee table.
SELECT
  e.fname AS employee_first_name,
  e.lname AS employee_last_name,
  s.fname AS superior_first_name,
  s.lname AS superior_last_name
FROM employee e
INNER JOIN employee s
  ON e.superior_emp_id = s.emp_id;

-- 4. Using a subquery, retrieve the fname and lname of the employees whose superior is 'Susan Hawthorne'.
SELECT fname, lname
FROM employee
WHERE superior_emp_id = (
  SELECT emp_id
  FROM employee
  WHERE fname = 'Susan' AND lname = 'Hawthorne'
);

-- 5. In the employee table, retrieve the superior names (fname and lname) present in department 1.
SELECT DISTINCT s.fname, s.lname
FROM employee e
INNER JOIN employee s
  ON e.superior_emp_id = s.emp_id
WHERE e.dept_id = 1;

-- 1) Top 5 selling bike models (units sold)
SELECT p.product_name, SUM(oi.quantity) AS units_sold
FROM production.products p
JOIN sales.order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_name
ORDER BY units_sold DESC
LIMIT 5;




-- 2) Trend in electric bike sales (units sold) from 2016 to 2018, by month & year
SELECT 
    YEAR(o.order_date) AS year,
    MONTH(o.order_date) AS month,
    SUM(oi.quantity) AS units_sold
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
JOIN production.products p ON oi.product_id = p.product_id
JOIN production.categories c ON p.category_id = c.category_id
WHERE c.category_name = 'Electric Bikes'
AND o.order_date BETWEEN '2016-01-01' AND '2018-12-31'
GROUP BY year, month
ORDER BY year, month;
-- 3) Stores sorted by average order value
SELECT 
    s.store_name,
    AVG(oi.quantity * oi.list_price * (1 - oi.discount)) AS avg_order_value
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY s.store_name
ORDER BY avg_order_value DESC;

-- 4) Stores sorted by average order quantity
SELECT 
    s.store_name,
    AVG(oi.quantity) AS avg_order_quantity
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY s.store_name
ORDER BY avg_order_quantity DESC;

-- 5) Stores sorted by total sales
SELECT 
    s.store_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY s.store_name
ORDER BY total_sales DESC;


-- 6) Store that sold the most children bikes
SELECT 
    s.store_name,
    SUM(oi.quantity) AS units_sold
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
JOIN production.products p ON oi.product_id = p.product_id
JOIN production.categories c ON p.category_id = c.category_id
WHERE c.category_name = 'Children Bicycles'
GROUP BY s.store_name
ORDER BY units_sold DESC
LIMIT 1;

-- 7) State with customers who bought the most bikes
SELECT 
    c.state,
    SUM(oi.quantity) AS units_sold
FROM sales.customers c
JOIN sales.orders o ON c.customer_id = o.customer_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY c.state
ORDER BY units_sold DESC
LIMIT 1;

-- 8) Most stocked bike in stores
SELECT 
    p.product_name,
    SUM(st.quantity) AS total_stock
FROM production.products p
JOIN production.stocks st ON p.product_id = st.product_id
GROUP BY p.product_name
ORDER BY total_stock DESC
LIMIT 1;

-- 9) Bike model sold at highest average discount
SELECT 
    p.product_name,
    AVG(oi.discount) AS avg_discount
FROM production.products p
JOIN sales.order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_name
ORDER BY avg_discount DESC
LIMIT 1;

-- 10) Does Santacruz sell more mountain bikes than Baldwin?
SELECT
    b.brand_name,
    SUM(oi.quantity) AS total_units_sold
FROM production.brands b
JOIN production.products p ON b.brand_id = p.brand_id
JOIN production.categories c ON p.category_id = c.category_id
JOIN sales.order_items oi ON p.product_id = oi.product_id
WHERE b.brand_name IN ('Santacruz', 'Baldwin')
  AND c.category_name ='Mountain Bikes'
GROUP BY b.brand_name
ORDER BY total_units_sold DESC;


-- 11) Sale value of the single largest order
SELECT 
    o.order_id,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS order_value
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY o.order_id
ORDER BY order_value DESC
LIMIT 1;

-- 12) Cheapest bike model sold in 2017
SELECT 
    p.product_name,
    MIN(oi.list_price) AS cheapest_price
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
JOIN production.products p ON oi.product_id = p.product_id
WHERE YEAR(o.order_date) = 2017
GROUP BY p.product_name
ORDER BY cheapest_price ASC
LIMIT 1;

-- 13) Total number of bikes sold
SELECT SUM(quantity) AS total_bikes_sold
FROM sales.order_items;

-- 14) Total sales per year (price)
SELECT 
    YEAR(o.order_date) AS year,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY year
ORDER BY year;

-- 15) Total sales per store (price)
SELECT 
    s.store_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY s.store_name
ORDER BY total_sales DESC;

-- 16) Sales driven by each staff member (total amount), descending order
SELECT 
    st.first_name || ' ' || st.last_name AS staff_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales
FROM sales.staffs st
JOIN sales.orders o ON st.staff_id = o.staff_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY staff_name
ORDER BY total_sales DESC;

-- 17) Average order fulfillment time (days)
SELECT 
    AVG(DATEDIFF(day, o.order_date, o.shipped_date)) AS avg_fulfillment_days
FROM sales.orders o
WHERE o.shipped_date IS NOT NULL;

-- 18) Store with shortest average fulfillment time
SELECT 
    s.store_name,
    AVG(DATEDIFF(day, o.order_date, o.shipped_date)) AS avg_fulfillment_days
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
WHERE o.shipped_date IS NOT NULL
GROUP BY s.store_name
ORDER BY avg_fulfillment_days ASC
LIMIT 1;

-- 19) Least 2 selling brands (by units sold)
SELECT 
    b.brand_name,
    SUM(oi.quantity) AS units_sold
FROM production.brands b
JOIN production.products p ON b.brand_id = p.brand_id
JOIN sales.order_items oi ON p.product_id = oi.product_id
GROUP BY b.brand_name
ORDER BY units_sold ASC
LIMIT 2;

-- 20) Top 3 months with most bike sales
SELECT 
    YEAR(o.order_date) AS year,
    MONTH(o.order_date) AS month,
    SUM(oi.quantity) AS units_sold
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY year, month
ORDER BY units_sold DESC
LIMIT 3;

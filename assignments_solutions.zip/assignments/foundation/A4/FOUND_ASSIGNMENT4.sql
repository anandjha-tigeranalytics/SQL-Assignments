Create Schema If not exists sales;
use Schema  sales;


Drop table IF exists sales.sales_order_Detail;
CREATE TABLE sales.sales_order_Detail (
	order_id INT ,
    Order_item_id Int,
	store_name VARCHAR (255) NOT NULL,
    cust_name VARCHAR (255) NOT NULL,
    product_name VARCHAR (255) NOT NULL,
	brand_name VARCHAR (255) NOT NULL,
	quantity INT NOT NULL,
	list_price DECIMAL (10, 2) NOT NULL,
	discount DECIMAL (4, 2) NOT NULL DEFAULT 0,
	order_date DATE NOT NULL,
	required_date DATE NOT NULL,
	shipped_date DATE
);
    Drop table IF exists sales.sales_order_summary ;
CREATE TABLE sales.sales_order_summary (
	order_date Date,
    product_name VARCHAR (255) NOT NULL,
	brand_name VARCHAR (255) NOT NULL,
    order_count Int,
    order_item_count Int,
	total_quantity INT ,
	total_list_price DECIMAL (10, 2) ,
	total_discount DECIMAL (4, 2) 
);




SQL Practice Questions & Solutions
-- 1. Find how many drawn games were played in each season
SELECT
    season,
    COUNT(*) AS total_drawn_games
FROM
    epl
WHERE
    home_score = away_score
GROUP BY
    season
ORDER BY
    season;

-- 2. Find the league winner in each season
WITH winners AS (
    SELECT
        season,
        CASE
            WHEN home_score > away_score THEN home_team
            WHEN home_score < away_score THEN away_team
            ELSE NULL
        END AS winner
    FROM
        epl
),
win_counts AS (
    SELECT
        season,
        winner AS league_winner,
        COUNT(*) AS wins
    FROM
        winners
    WHERE
        winner IS NOT NULL
    GROUP BY
        season,
        winner
),
ranked_winners AS (
    SELECT
        season,
        league_winner,
        wins,
        ROW_NUMBER() OVER (PARTITION BY season ORDER BY wins DESC) AS rank_num
    FROM
        win_counts
)
SELECT
    season,
    league_winner,
    wins
FROM
    ranked_winners
WHERE
    rank_num = 1
ORDER BY
    season;

-- 3. Find the team with most goals scored in each season and their rank
WITH goals AS (
    SELECT season, home_team AS team, SUM(home_score) AS goals_scored
    FROM epl
    GROUP BY season, home_team
    UNION ALL
    SELECT season, away_team AS team, SUM(away_score) AS goals_scored
    FROM epl
    GROUP BY season, away_team
),
total_goals AS (
    SELECT season, team, SUM(goals_scored) AS total_goals
    FROM goals
    GROUP BY season, team
),
ranked_goals AS (
    SELECT
        season,
        team,
        total_goals,
        RANK() OVER (PARTITION BY season ORDER BY total_goals DESC) AS rank
    FROM
        total_goals
)
SELECT
    season,
    team,
    total_goals,
    rank
FROM
    ranked_goals
WHERE
    rank = 1
ORDER BY
    season;

-- 4. Find the team with least goals conceded in each season and their rank
WITH conceded AS (
    SELECT season, home_team AS team, SUM(away_score) AS goals_conceded
    FROM epl
    GROUP BY season, home_team
    UNION ALL
    SELECT season, away_team AS team, SUM(home_score) AS goals_conceded
    FROM epl
    GROUP BY season, away_team
),
total_conceded AS (
    SELECT season, team, SUM(goals_conceded) AS total_conceded
    FROM conceded
    GROUP BY season, team
),
ranked_conceded AS (
    SELECT
        season,
        team,
        total_conceded,
        RANK() OVER (PARTITION BY season ORDER BY total_conceded ASC) AS rank
    FROM
        total_conceded
)
SELECT
    season,
    team,
    total_conceded,
    rank
FROM
    ranked_conceded
WHERE
    rank = 1
ORDER BY
    season;

-- 5. Find the team with the most away wins in each season
WITH away_wins AS (
    SELECT
        season,
        away_team AS team,
        COUNT(*) AS away_win_count
    FROM
        epl
    WHERE
        away_score > home_score
    GROUP BY
        season,
        away_team
),
ranked_away AS (
    SELECT
        season,
        team,
        away_win_count,
        RANK() OVER (PARTITION BY season ORDER BY away_win_count DESC) AS rank
    FROM
        away_wins
)
SELECT
    season,
    team,
    away_win_count
FROM
    ranked_away
WHERE
    rank = 1
ORDER BY
    season;

-- 6. Find the team which got relegated most number of times between 2014-2015 to 2020-2021 seasons
WITH results AS (
    SELECT
        season,
        home_team AS team,
        SUM(CASE WHEN home_score > away_score THEN 3 WHEN home_score = away_score THEN 1 ELSE 0 END) AS points
    FROM
        epl
    GROUP BY
        season,
        home_team
    UNION ALL
    SELECT
        season,
        away_team AS team,
        SUM(CASE WHEN away_score > home_score THEN 3 WHEN away_score = home_score THEN 1 ELSE 0 END) AS points
    FROM
        epl
    GROUP BY
        season,
        away_team
),
total_points AS (
    SELECT
        season,
        team,
        SUM(points) AS total_points
    FROM
        results
    GROUP BY
        season,
        team
),
ranked_teams AS (
    SELECT
        season,
        team,
        total_points,
        RANK() OVER (PARTITION BY season ORDER BY total_points ASC) AS rank
    FROM
        total_points
),
relegated AS (
    SELECT
        team
    FROM
        ranked_teams
    WHERE
        rank <= 3
        AND season BETWEEN '2014-2015' AND '2020-2021'
)
SELECT
    team,
    COUNT(*) AS relegation_count
FROM
    relegated
GROUP BY
    team
ORDER BY
    relegation_count DESC
LIMIT 1;

-- 7. Find the teams which got selected to play in Champions League the most number of times between 2014-2015 to 2020-2021 seasons
WITH results AS (
    SELECT
        season,
        home_team AS team,
        SUM(CASE WHEN home_score > away_score THEN 3 WHEN home_score = away_score THEN 1 ELSE 0 END) AS points
    FROM epl
    GROUP BY season, home_team
    UNION ALL
    SELECT
        season,
        away_team AS team,
        SUM(CASE WHEN away_score > home_score THEN 3 WHEN away_score = home_score THEN 1 ELSE 0 END) AS points
    FROM epl
    GROUP BY season, away_team
),
total_points AS (
    SELECT
        season,
        team,
        SUM(points) AS total_points
    FROM results
    GROUP BY season, team
),
ranked_teams AS (
    SELECT
        season,
        team,
        total_points,
        RANK() OVER (PARTITION BY season ORDER BY total_points DESC) AS rank
    FROM total_points
),
champions_league_teams AS (
    SELECT
        team
    FROM
        ranked_teams
    WHERE
        rank <= 4
        AND season BETWEEN '2014-2015' AND '2020-2021'
)
SELECT
    team,
    COUNT(*) AS champions_league_count
FROM
    champions_league_teams
GROUP BY
    team
ORDER BY
    champions_league_count DESC
LIMIT 1;

-- 8. Which Team have played the least number of games each season
WITH all_games AS (
    SELECT season, home_team AS team
    FROM epl
    UNION ALL
    SELECT season, away_team AS team
    FROM epl
),
game_counts AS (
    SELECT
        season,
        team,
        COUNT(*) AS total_games
    FROM all_games
    GROUP BY season, team
),
ranked_teams AS (
    SELECT
        season,
        team,
        total_games,
        RANK() OVER (PARTITION BY season ORDER BY total_games ASC) AS rank
    FROM game_counts
)
SELECT
    season,
    team,
    total_games
FROM
    ranked_teams
WHERE
    rank = 1
ORDER BY
    season;

-- 9. Which team have scored maximum away goals across seasons
SELECT
    away_team,
    SUM(away_score) AS total_away_goals
FROM
    epl
GROUP BY
    away_team
ORDER BY
    total_away_goals DESC
LIMIT 1;

-- 10. Which season has least number of home goals scored
SELECT
    season,
    SUM(home_score) AS total_home_goals
FROM
    epl
GROUP BY
    season
ORDER BY
    total_home_goals ASC
LIMIT 1;

